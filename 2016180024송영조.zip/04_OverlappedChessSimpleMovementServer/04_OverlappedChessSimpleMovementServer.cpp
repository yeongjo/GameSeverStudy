#include <iostream>
#include <map>
#include <vector>
#include <WS2tcpip.h>
#pragma comment(lib, "Ws2_32.lib")
using namespace std;
#pragma pack(1)

#define MAX_BUFFER        1024
#define SERVER_PORT        3500
#define MAPSIZE 8


class PlayerInfo {
public:
	unsigned char id;
	unsigned char posX;
	unsigned char posY;
};

class SendPacket {
public:
	unsigned char playerCnt;
	PlayerInfo playerInfos[10];
};

constexpr int RECV_BUF_SIZE = 1;
constexpr int SEND_BUF_SIZE = sizeof(PlayerInfo);
constexpr int CONSOLE_START_Y = 1;

char chessBoard[MAPSIZE][MAPSIZE];

struct SOCKETINFO {
	WSAOVERLAPPED recvOverlapped; // ����ü �� �տ� �ִ� ���� �ּҰ� ����ü�� �ּҸ� ����Ҷ� ���ȴ�.
	WSAOVERLAPPED sendOverlapped[2]; // 0�� id�����°ſ� ��� 1�� �÷��̾� ���� �����µ� ��� ���߿� Ǯ���ؼ� ����ϴ°� ����ų� �ؾ��ҵ�
	WSABUF dataBuffer;
	SOCKET socket;
	char messageBuffer[MAX_BUFFER];
	PlayerInfo player;
};

map<SOCKET, SOCKETINFO> clients;
map<LPWSAOVERLAPPED, SOCKETINFO*> clientsFromRecv;
map<LPWSAOVERLAPPED, SOCKETINFO*> clientsFromSend0;
map<LPWSAOVERLAPPED, SOCKETINFO*> clientsFromSend1;
unsigned short currentPlayerId = 0;

void display_error(const char* msg, int err_no) {
	WCHAR* lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, err_no, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	cout << msg;
	wcout << lpMsgBuf << endl;
	LocalFree(lpMsgBuf);
}

int clamp(int value, int min, int max) {
	return value < min ? min : value > max ? max : value;
}

void gotoxy(int x, int y) {
	COORD Pos;
	Pos.X = x;
	Pos.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}

bool getKeyInput(PlayerInfo& playerInfo, char keyCode) {
	switch (keyCode)
	{
	case 72: // ��
		playerInfo.posY--;
		break;
	case 80: // �Ʒ�
		playerInfo.posY++;
		break;
	case 75: // ��
		playerInfo.posX--;
		break;
	case 77: // ����
		playerInfo.posX++;
		break;
	default:
		return false;
	}
	playerInfo.posX = clamp(playerInfo.posX, 0, MAPSIZE - 1);
	playerInfo.posY = clamp(playerInfo.posY, 0, MAPSIZE - 1);
	return true;
}

void CALLBACK recv_callback(DWORD Error, DWORD dataBytes, LPWSAOVERLAPPED overlapped, DWORD lnFlags);
void CALLBACK sendPlayerInfosCallback(DWORD Error, DWORD dataBytes, LPWSAOVERLAPPED overlapped, DWORD lnFlags);

void sendEveryPlayersInfo(SOCKETINFO* socketInfo) {
	auto lter = clients.begin();
	const auto clientCnt = clients.size();
	if(clientCnt == 0){
		return;
	}

	int i = 0;
	while (lter != clients.end()) {
		auto& info = lter->second;
		clientsFromSend1[&info.sendOverlapped[1]] = &info;
		reinterpret_cast<SendPacket*>(socketInfo->messageBuffer)->playerInfos[i] = info.player;
		++lter;
		++i;
	}
	reinterpret_cast<SendPacket*>(socketInfo->messageBuffer)->playerCnt = clientCnt;
	
	socketInfo->dataBuffer.buf = socketInfo->messageBuffer;
	socketInfo->dataBuffer.len = (SEND_BUF_SIZE * clientCnt) + sizeof SendPacket::playerCnt;
	memset(&(socketInfo->sendOverlapped[1]), 0, sizeof(WSAOVERLAPPED)); // �����ϱ����� 0���� �ʱ�ȭ
	WSASend(socketInfo->socket, &(socketInfo->dataBuffer), 1, NULL, 0, &socketInfo->sendOverlapped[1], sendPlayerInfosCallback);
}

void CALLBACK recv_callback(DWORD Error, DWORD dataBytes, LPWSAOVERLAPPED overlapped, DWORD lnFlags) {
	auto& socket = clientsFromRecv[overlapped]->socket;
	auto& client = clients[socket];

	if (dataBytes == 0)
	{
		cout << "recv: dataBytes == 0 Remove socket from list" << endl;
		closesocket(client.socket);
		clients.erase(socket);
		return;
	}  // Ŭ���̾�Ʈ�� closesocket�� ���� ���
	cout << "From client : " << (int)client.messageBuffer[0] << " (" << dataBytes << ") bytes)\n";

	getKeyInput(client.player, client.messageBuffer[0]);
	sendEveryPlayersInfo(&client);
}

void CALLBACK sendPlayerInfosCallback(DWORD Error, DWORD dataBytes, LPWSAOVERLAPPED overlapped, DWORD lnFlags) {
	DWORD flags = 0;
	auto& socket = clientsFromSend1[overlapped]->socket;
	auto& client = clients[socket];
	
	if (dataBytes == 0) {
		cout << "send: dataBytes == 0 Remove socket from list" << endl;
		closesocket(client.socket);
		clients.erase(socket);
		return;
	}  // Ŭ���̾�Ʈ�� closesocket�� ���� ���

	// WSASend(���信 ����)�� �ݹ��� ���

	PlayerInfo* sendedInfo = (PlayerInfo*)client.dataBuffer.buf;
	cout << "TRACE - Send message : " << sendedInfo->id << ": " << sendedInfo->posX << ": " << sendedInfo->posY << ": " << " (" << dataBytes << " bytes)\n";
	clientsFromRecv[&client.recvOverlapped] = &client;
	memset(&(client.recvOverlapped), 0, sizeof(WSAOVERLAPPED));
	client.dataBuffer.buf = client.messageBuffer;
	client.dataBuffer.len = 1;
	WSARecv(client.socket, &client.dataBuffer, 1, 0, &flags, &client.recvOverlapped, recv_callback);
}

void CALLBACK sendPlayerIdCallback(DWORD Error, DWORD dataBytes, LPWSAOVERLAPPED overlapped, DWORD lnFlags) {
	DWORD flags = 0;
	auto& socket = clientsFromSend0[overlapped]->socket;
	auto& client = clients[socket];

	if (dataBytes == 0) {
		cout << "send: dataBytes == 0 Remove socket from list" << endl;
		closesocket(client.socket);
		clients.erase(socket);
		return;
	}  // Ŭ���̾�Ʈ�� closesocket�� ���� ���

	// WSASend(���信 ����)�� �ݹ��� ���

	auto id = *(unsigned short*)client.dataBuffer.buf;
	cout << "TRACE - Send message : " << id << ": " << " (" << dataBytes << " bytes)\n";

	sendEveryPlayersInfo(&client);
}

void drawMap() {
	gotoxy(0, CONSOLE_START_Y);
	for (size_t i = 0; i < MAPSIZE; i++)
	{
		for (size_t j = 0; j < MAPSIZE; j++)
		{
			chessBoard[i][j] = '+';
		}
	}

	auto iter = clients.begin();
	while(iter != clients.end()){
		chessBoard[iter->second.player.posX][iter->second.player.posY] = 'A';
	}

	for (size_t i = 0; i < MAPSIZE; i++)
	{
		for (size_t j = 0; j < MAPSIZE; j++)
		{
			cout << chessBoard[i][j];
		}
		cout << endl;
	}
}

int main() {
	wcout.imbue(locale("korean"));
	WSADATA WSAData;
	WSAStartup(MAKEWORD(2, 2), &WSAData);
	SOCKET listenSocket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	SOCKADDR_IN serverAddr;
	memset(&serverAddr, 0, sizeof(SOCKADDR_IN));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	::bind(listenSocket, (struct sockaddr*)&serverAddr, sizeof(SOCKADDR_IN));
	listen(listenSocket, 5);
	SOCKADDR_IN clientAddr;
	int addrLen = sizeof(SOCKADDR_IN);
	memset(&clientAddr, 0, addrLen);

	while (true) {
		SOCKET clientSocket = accept(listenSocket, (struct sockaddr*)&clientAddr, &addrLen);
		clients[clientSocket] = SOCKETINFO{};
		clients[clientSocket].socket = clientSocket;
		clients[clientSocket].player.id = currentPlayerId++;
		clients[clientSocket].dataBuffer.len = sizeof(clients[clientSocket].player.id);
		clients[clientSocket].dataBuffer.buf = reinterpret_cast<char*>(&clients[clientSocket].player.id);
		memset(&clients[clientSocket].sendOverlapped[0], 0, sizeof(WSAOVERLAPPED));
		DWORD flags = 0;

		clientsFromSend0[&clients[clientSocket].sendOverlapped[0]] = &clients[clientSocket];
		auto result = WSASend(clients[clientSocket].socket, &clients[clientSocket].dataBuffer, 1, NULL, 0, &clients[clientSocket].sendOverlapped[0], sendPlayerIdCallback);
		if(result == SOCKET_ERROR){
			cout << "ERROR!: " << clients[clientSocket].player.id << endl;
			display_error("Send error: ", WSAGetLastError());
		}
	}
	closesocket(listenSocket);
	WSACleanup();
}

